This is a simple example package. 
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
